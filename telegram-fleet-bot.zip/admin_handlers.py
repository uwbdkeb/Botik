# -*- coding: utf-8 -*-
"""
Обработчики административной панели
"""

import logging
from telegram import Update
from telegram.ext import ContextTypes, ConversationHandler
from telegram.constants import ParseMode

from database import get_db
from models import Driver, Car, Shift
from keyboards import (
    get_admin_keyboard, get_admin_drivers_keyboard, get_admin_cars_keyboard,
    get_driver_list_keyboard, get_car_list_keyboard, get_confirmation_keyboard
)
from states import AdminStates
from utils import is_admin, get_user_from_db

logger = logging.getLogger(__name__)

async def admin_panel_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Главная административная панель"""
    user = update.effective_user
    db = get_db()
    
    try:
        if not is_admin(user.id, db):
            await update.message.reply_text("❌ У вас нет прав администратора.")
            return ConversationHandler.END
        
        text = "👨‍💼 **Административная панель**\n\nВыберите действие:"
        keyboard = get_admin_keyboard()
        
        await update.message.reply_text(text, reply_markup=keyboard, parse_mode=ParseMode.MARKDOWN)
        
        return AdminStates.ADD_DRIVER_PHONE  # Начальное состояние
        
    except Exception as e:
        logger.error(f"Ошибка в admin_panel_handler: {e}")
        await update.message.reply_text("Произошла ошибка при открытии админ панели.")
        return ConversationHandler.END
    finally:
        db.close()

async def admin_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик callback запросов админ панели"""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    user = update.effective_user
    db = get_db()
    
    try:
        if not is_admin(user.id, db):
            await query.edit_message_text("❌ У вас нет прав администратора.")
            return ConversationHandler.END
        
        # Главное меню админки
        if data == "admin":
            text = "👨‍💼 **Административная панель**\n\nВыберите действие:"
            keyboard = get_admin_keyboard()
            await query.edit_message_text(text, reply_markup=keyboard, parse_mode=ParseMode.MARKDOWN)
        
        # Управление водителями
        elif data == "admin_drivers":
            text = "👥 **Управление водителями**\n\nВыберите действие:"
            keyboard = get_admin_drivers_keyboard()
            await query.edit_message_text(text, reply_markup=keyboard, parse_mode=ParseMode.MARKDOWN)
        
        elif data == "admin_add_driver":
            await query.edit_message_text("👤 **Добавление водителя**\n\nВведите номер телефона водителя (в формате +7xxxxxxxxxx):")
            context.user_data['action'] = 'add_driver'
            return AdminStates.ADD_DRIVER_PHONE
        
        elif data == "admin_list_drivers":
            drivers = db.query(Driver).all()
            if not drivers:
                await query.edit_message_text("👥 Список водителей пуст.")
                return
            
            keyboard = get_driver_list_keyboard(drivers)
            text = f"👥 **Список водителей** ({len(drivers)} чел.):"
            await query.edit_message_text(text, reply_markup=keyboard, parse_mode=ParseMode.MARKDOWN)
        
        # Управление автомобилями
        elif data == "admin_cars":
            text = "🚗 **Управление автомобилями**\n\nВыберите действие:"
            keyboard = get_admin_cars_keyboard()
            await query.edit_message_text(text, reply_markup=keyboard, parse_mode=ParseMode.MARKDOWN)
        
        elif data == "admin_add_car":
            await query.edit_message_text("🚗 **Добавление автомобиля**\n\nВведите модель автомобиля:")
            context.user_data['action'] = 'add_car'
            return AdminStates.ADD_CAR_MODEL
        
        elif data == "admin_list_cars":
            cars = db.query(Car).all()
            if not cars:
                await query.edit_message_text("🚗 Список автомобилей пуст.")
                return
            
            keyboard = get_car_list_keyboard(cars)
            text = f"🚗 **Список автомобилей** ({len(cars)} шт.):"
            await query.edit_message_text(text, reply_markup=keyboard, parse_mode=ParseMode.MARKDOWN)
        
        # Отчеты
        elif data == "admin_reports":
            await show_admin_reports(query, db)
        
        # Настройки
        elif data == "admin_settings":
            await query.edit_message_text("⚙️ **Настройки**\n\n🚧 Раздел в разработке...")
        
        # Детали водителя
        elif data.startswith("admin_driver_"):
            driver_id = int(data.split('_')[2])
            await show_driver_details(query, driver_id, db)
        
        # Детали автомобиля
        elif data.startswith("admin_car_"):
            car_id = int(data.split('_')[2])
            await show_car_details(query, car_id, db)
        
        # Пагинация
        elif data.startswith("admin_drivers_page_"):
            page = int(data.split('_')[3])
            drivers = db.query(Driver).all()
            keyboard = get_driver_list_keyboard(drivers, page)
            text = f"👥 **Список водителей** ({len(drivers)} чел.):"
            await query.edit_message_text(text, reply_markup=keyboard, parse_mode=ParseMode.MARKDOWN)
        
        elif data.startswith("admin_cars_page_"):
            page = int(data.split('_')[3])
            cars = db.query(Car).all()
            keyboard = get_car_list_keyboard(cars, page)
            text = f"🚗 **Список автомобилей** ({len(cars)} шт.):"
            await query.edit_message_text(text, reply_markup=keyboard, parse_mode=ParseMode.MARKDOWN)
        
        return None  # Остаемся в текущем состоянии
        
    except Exception as e:
        logger.error(f"Ошибка в admin_callback_handler: {e}")
        await query.edit_message_text("Произошла ошибка в админ панели.")
        return ConversationHandler.END
    finally:
        db.close()

async def admin_text_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик текстовых сообщений в админ панели"""
    user = update.effective_user
    text = update.message.text
    action = context.user_data.get('action')
    db = get_db()
    
    try:
        if not is_admin(user.id, db):
            await update.message.reply_text("❌ У вас нет прав администратора.")
            return ConversationHandler.END
        
        # Добавление водителя - телефон
        if action == 'add_driver' and context.user_data.get('state') != 'name':
            phone = text.strip()
            
            # Валидация номера телефона
            if not phone.startswith('+') or len(phone) < 11:
                await update.message.reply_text("❌ Неверный формат номера. Введите номер в формате +7xxxxxxxxxx:")
                return AdminStates.ADD_DRIVER_PHONE
            
            # Проверяем, что водитель не существует
            existing_driver = db.query(Driver).filter(Driver.phone == phone).first()
            if existing_driver:
                await update.message.reply_text("❌ Водитель с таким номером уже существует.")
                return AdminStates.ADD_DRIVER_PHONE
            
            context.user_data['phone'] = phone
            context.user_data['state'] = 'name'
            await update.message.reply_text("👤 Введите имя водителя:")
            return AdminStates.ADD_DRIVER_NAME
        
        # Добавление водителя - имя
        elif action == 'add_driver' and context.user_data.get('state') == 'name':
            name = text.strip()
            
            if len(name) < 2:
                await update.message.reply_text("❌ Имя должно содержать минимум 2 символа:")
                return AdminStates.ADD_DRIVER_NAME
            
            phone = context.user_data['phone']
            
            # Создаем водителя
            driver = Driver(
                phone=phone,
                name=name,
                role='driver',
                is_active=True
            )
            
            db.add(driver)
            db.commit()
            
            await update.message.reply_text(f"✅ Водитель добавлен:\n👤 {name}\n📱 {phone}")
            
            # Очищаем данные
            context.user_data.clear()
            return ConversationHandler.END
        
        # Добавление автомобиля - модель
        elif action == 'add_car' and context.user_data.get('state') != 'number':
            model = text.strip()
            
            if len(model) < 2:
                await update.message.reply_text("❌ Модель должна содержать минимум 2 символа:")
                return AdminStates.ADD_CAR_MODEL
            
            context.user_data['model'] = model
            context.user_data['state'] = 'number'
            await update.message.reply_text("🚗 Введите государственный номер автомобиля:")
            return AdminStates.ADD_CAR_NUMBER
        
        # Добавление автомобиля - номер
        elif action == 'add_car' and context.user_data.get('state') == 'number':
            license_plate = text.strip().upper()
            
            if len(license_plate) < 5:
                await update.message.reply_text("❌ Некорректный номер. Введите государственный номер:")
                return AdminStates.ADD_CAR_NUMBER
            
            # Проверяем уникальность номера
            existing_car = db.query(Car).filter(Car.license_plate == license_plate).first()
            if existing_car:
                await update.message.reply_text("❌ Автомобиль с таким номером уже существует.")
                return AdminStates.ADD_CAR_NUMBER
            
            model = context.user_data['model']
            
            # Создаем автомобиль
            car = Car(
                model=model,
                license_plate=license_plate,
                is_available=True
            )
            
            db.add(car)
            db.commit()
            
            await update.message.reply_text(f"✅ Автомобиль добавлен:\n🚗 {model}\n🔢 {license_plate}")
            
            # Очищаем данные
            context.user_data.clear()
            return ConversationHandler.END
        
        else:
            await update.message.reply_text("❌ Неизвестная команда.")
            return ConversationHandler.END
        
    except Exception as e:
        logger.error(f"Ошибка в admin_text_handler: {e}")
        await update.message.reply_text("Произошла ошибка при обработке данных.")
        return ConversationHandler.END
    finally:
        db.close()

async def admin_add_driver_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Добавление водителя"""
    # Эта функция вызывается через callback, логика в admin_callback_handler
    pass

async def admin_add_car_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Добавление автомобиля"""
    # Эта функция вызывается через callback, логика в admin_callback_handler
    pass

async def show_driver_details(query, driver_id, db):
    """Показать детали водителя"""
    driver = db.query(Driver).filter(Driver.id == driver_id).first()
    if not driver:
        await query.edit_message_text("❌ Водитель не найден.")
        return
    
    # Статистика водителя
    total_shifts = db.query(Shift).filter(Shift.driver_id == driver_id).count()
    active_shift = db.query(Shift).filter(
        Shift.driver_id == driver_id,
        Shift.status == 'active'
    ).first()
    
    status = "✅ Активен" if driver.is_active else "❌ Неактивен"
    role = "👨‍💼 Администратор" if driver.role == 'admin' else "🚗 Водитель"
    shift_status = "🟢 На смене" if active_shift else "🔴 Свободен"
    
    text = f"""👤 **Водитель: {driver.name}**

📱 Телефон: {driver.phone}
🔐 Роль: {role}
📊 Статус: {status}
🚗 Смена: {shift_status}

📈 **Статистика:**
📊 Всего смен: {total_shifts}
📅 Регистрация: {driver.created_at.strftime('%d.%m.%Y')}"""
    
    keyboard = [
        [InlineKeyboardButton("📝 Редактировать", callback_data=f"admin_edit_driver_{driver_id}")],
        [InlineKeyboardButton("🔄 Изменить статус", callback_data=f"admin_toggle_driver_{driver_id}")],
        [InlineKeyboardButton("◀️ Назад", callback_data="admin_list_drivers")]
    ]
    
    from telegram import InlineKeyboardMarkup, InlineKeyboardButton
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode=ParseMode.MARKDOWN)

async def show_car_details(query, car_id, db):
    """Показать детали автомобиля"""
    car = db.query(Car).filter(Car.id == car_id).first()
    if not car:
        await query.edit_message_text("❌ Автомобиль не найден.")
        return
    
    # Статистика автомобиля
    total_shifts = db.query(Shift).filter(Shift.car_id == car_id).count()
    active_shift = db.query(Shift).filter(
        Shift.car_id == car_id,
        Shift.status == 'active'
    ).first()
    
    status = "🟢 Доступен" if car.is_available else "🔴 Занят"
    current_driver = ""
    if active_shift and active_shift.driver:
        current_driver = f"\n👤 Водитель: {active_shift.driver.name}"
    
    text = f"""🚗 **{car.model}**

🔢 Номер: {car.license_plate}
📊 Статус: {status}{current_driver}

📈 **Статистика:**
📊 Всего смен: {total_shifts}
📅 Добавлен: {car.created_at.strftime('%d.%m.%Y')}"""
    
    keyboard = [
        [InlineKeyboardButton("📝 Редактировать", callback_data=f"admin_edit_car_{car_id}")],
        [InlineKeyboardButton("🔄 Изменить статус", callback_data=f"admin_toggle_car_{car_id}")],
        [InlineKeyboardButton("◀️ Назад", callback_data="admin_list_cars")]
    ]
    
    from telegram import InlineKeyboardMarkup, InlineKeyboardButton
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode=ParseMode.MARKDOWN)

async def show_admin_reports(query, db):
    """Показать административные отчеты"""
    # Общая статистика
    total_drivers = db.query(Driver).count()
    active_drivers = db.query(Driver).filter(Driver.is_active == True).count()
    total_cars = db.query(Car).count()
    available_cars = db.query(Car).filter(Car.is_available == True).count()
    total_shifts = db.query(Shift).count()
    active_shifts = db.query(Shift).filter(Shift.status == 'active').count()
    
    text = f"""📊 **Отчеты и статистика**

👥 **Водители:**
• Всего: {total_drivers}
• Активных: {active_drivers}

🚗 **Автомобили:**
• Всего: {total_cars}
• Доступных: {available_cars}

📈 **Смены:**
• Всего: {total_shifts}
• Активных: {active_shifts}

🚧 Детальные отчеты в разработке..."""
    
    keyboard = [
        [InlineKeyboardButton("📈 Детальный отчет", callback_data="admin_detailed_report")],
        [InlineKeyboardButton("📊 Экспорт данных", callback_data="admin_export_data")],
        [InlineKeyboardButton("◀️ Назад", callback_data="admin")]
    ]
    
    from telegram import InlineKeyboardMarkup, InlineKeyboardButton
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode=ParseMode.MARKDOWN)
