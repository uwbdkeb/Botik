# Fleet Management Telegram Bot

## Overview

This is a fully functional Telegram bot application for fleet management that allows drivers to manage vehicle shifts, take required photos, and handle administrative tasks. The bot uses SQLAlchemy ORM with PostgreSQL database and implements a conversation-based interface for managing vehicle operations.

**Status**: ✅ **DEPLOYED AND RUNNING** (as of July 30, 2025)
- Bot is live and processing messages
- PostgreSQL database configured and populated
- All core features implemented and tested

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes (July 30, 2025)

✅ Bot successfully deployed and running
✅ PostgreSQL database configured and connected
✅ Fixed python-telegram-bot version conflicts (downgraded to 20.8)
✅ Database tables created and populated with test data
✅ Added test administrator (+79123456789) and sample vehicles
✅ Bot actively processing Telegram messages
✅ All core functionality operational

## System Architecture

### Backend Architecture
- **Framework**: Python with python-telegram-bot library
- **Database ORM**: SQLAlchemy with declarative base
- **Database**: SQLite (configurable via DATABASE_URL)
- **Architecture Pattern**: MVC-like structure with handlers, models, and utilities
- **State Management**: ConversationHandler for multi-step workflows

### Key Design Decisions
- **Modular Structure**: Separate files for different concerns (handlers, models, keyboards, etc.)
- **Configuration Management**: Environment variables with fallbacks
- **Logging**: Comprehensive logging to both file and console
- **Role-based Access**: Admin/driver role distinction with permission checks

## Key Components

### Core Models (`models.py`)
- **Driver**: User management with Telegram integration, role-based access
- **Car**: Vehicle inventory with availability tracking
- **Shift**: Work session management linking drivers to cars
- **ShiftPhoto**: Photo documentation for shifts

### Handler System
- **Main Handlers** (`handlers.py`): Core bot functionality including start, contact handling, fleet management
- **Admin Handlers** (`admin_handlers.py`): Administrative panel for managing drivers and cars
- **Conversation States** (`states.py`): Multi-step workflow management for shifts and admin tasks

### User Interface
- **Keyboards** (`keyboards.py`): Inline and reply keyboard generators for different contexts
- **State-driven Navigation**: Context-aware interface based on user role and current workflow

### Utilities (`utils.py`)
- **Permission System**: Admin role verification
- **Database Helpers**: User lookup and photo management utilities
- **Error Handling**: Centralized error management

## Data Flow

### User Authentication Flow
1. User starts bot with `/start` command
2. If not registered, requests phone contact
3. System validates against driver database
4. Grants appropriate access based on role

### Shift Management Flow
1. Driver accesses fleet overview
2. Selects available vehicle
3. Goes through photo documentation workflow (speedometer, fuel, oil, interior)
4. Shift becomes active, vehicle marked unavailable
5. End shift process with final documentation

### Admin Workflow
1. Admin accesses admin panel
2. Can add new drivers or vehicles
3. Manages system permissions and availability

## External Dependencies

### Required Python Packages
- `python-telegram-bot`: Telegram API integration
- `SQLAlchemy`: Database ORM
- `python-dotenv`: Environment variable management

### Environment Variables
- `BOT_TOKEN`: Telegram bot API token (required)
- `DATABASE_URL`: Database connection string (defaults to SQLite)
- `ADMIN_IDS`: Comma-separated admin user IDs
- `DEBUG`: Debug mode flag

### Telegram Integration
- Bot API for messaging and callback handling
- File API for photo management
- Contact sharing for user verification

## Deployment Strategy

### Configuration
- Environment-based configuration with secure token management
- SQLite for development, configurable for production databases
- File-based logging with rotation capability

### Database Setup
- Automatic table creation on startup
- Migration-ready SQLAlchemy models
- Admin user bootstrap capability

### Error Handling
- Comprehensive exception handling in all handlers
- Graceful degradation for database connection issues
- User-friendly error messages in Russian

### Security Considerations
- Role-based access control
- Phone number verification for user registration
- Admin permission validation on sensitive operations

## Technical Notes

The application is structured for easy extension and maintenance:
- Conversation handlers manage complex multi-step workflows
- Modular keyboard system for consistent UI
- Centralized configuration and utilities
- Russian language interface with UTF-8 support
- Ready for scaling from SQLite to PostgreSQL when needed