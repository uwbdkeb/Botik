#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Telegram бот для управления автопарком
Основной файл приложения
"""

import logging
import os
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, filters
from telegram.ext import ConversationHandler

from config import BOT_TOKEN, DATABASE_URL
from database import init_db
from handlers import (
    start_handler, contact_handler, profile_handler, fleet_handler,
    start_shift_handler, end_shift_handler, help_handler,
    shift_photo_handler, shift_text_handler, shift_callback_handler,
    cancel_shift_handler
)
from admin_handlers import (
    admin_panel_handler, admin_callback_handler, admin_add_driver_handler,
    admin_add_car_handler, admin_text_handler
)
from states import ShiftStates, AdminStates

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    handlers=[
        logging.FileHandler('bot.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def main():
    """Запуск бота"""
    # Инициализация базы данных
    init_db()
    
    # Создание приложения
    application = Application.builder().token(BOT_TOKEN).build()
    
    # Conversation Handler для смен
    shift_conv_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(start_shift_handler, pattern='^start_shift_')],
        states={
            ShiftStates.SPEEDOMETER_PHOTO: [
                MessageHandler(filters.PHOTO, shift_photo_handler),
                MessageHandler(filters.TEXT & ~filters.COMMAND, shift_text_handler)
            ],
            ShiftStates.FUEL_PHOTO: [
                MessageHandler(filters.PHOTO, shift_photo_handler),
                MessageHandler(filters.TEXT & ~filters.COMMAND, shift_text_handler)
            ],
            ShiftStates.OIL_PHOTO: [
                MessageHandler(filters.PHOTO, shift_photo_handler),
                MessageHandler(filters.TEXT & ~filters.COMMAND, shift_text_handler)
            ],
            ShiftStates.INTERIOR_PHOTO: [
                MessageHandler(filters.PHOTO, shift_photo_handler),
                MessageHandler(filters.TEXT & ~filters.COMMAND, shift_text_handler)
            ],
            ShiftStates.END_SPEEDOMETER: [
                MessageHandler(filters.PHOTO, shift_photo_handler),
                MessageHandler(filters.TEXT & ~filters.COMMAND, shift_text_handler)
            ],
            ShiftStates.END_FUEL_PHOTO: [
                MessageHandler(filters.PHOTO, shift_photo_handler),
                MessageHandler(filters.TEXT & ~filters.COMMAND, shift_text_handler)
            ]
        },
        fallbacks=[
            CommandHandler('cancel', cancel_shift_handler),
            CallbackQueryHandler(shift_callback_handler)
        ],
        map_to_parent={
            ConversationHandler.END: ConversationHandler.END
        }
    )
    
    # Conversation Handler для админ панели
    admin_conv_handler = ConversationHandler(
        entry_points=[CommandHandler('admin', admin_panel_handler)],
        states={
            AdminStates.ADD_DRIVER_PHONE: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, admin_text_handler)
            ],
            AdminStates.ADD_DRIVER_NAME: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, admin_text_handler)
            ],
            AdminStates.ADD_CAR_MODEL: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, admin_text_handler)
            ],
            AdminStates.ADD_CAR_NUMBER: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, admin_text_handler)
            ]
        },
        fallbacks=[
            CommandHandler('cancel', cancel_shift_handler),
            CallbackQueryHandler(admin_callback_handler)
        ]
    )
    
    # Добавление обработчиков
    application.add_handler(CommandHandler('start', start_handler))
    application.add_handler(CommandHandler('help', help_handler))
    application.add_handler(CommandHandler('profile', profile_handler))
    application.add_handler(CommandHandler('fleet', fleet_handler))
    
    # Добавление conversation handlers
    application.add_handler(shift_conv_handler)
    application.add_handler(admin_conv_handler)
    
    # Обработчик контактов
    application.add_handler(MessageHandler(filters.CONTACT, contact_handler))
    
    # Обработчики callback query
    application.add_handler(CallbackQueryHandler(shift_callback_handler, pattern='^end_shift_'))
    application.add_handler(CallbackQueryHandler(admin_callback_handler, pattern='^admin_'))
    
    # Запуск бота
    logger.info("Запуск бота...")
    application.run_polling(allowed_updates=['message', 'callback_query'])

if __name__ == '__main__':
    main()
