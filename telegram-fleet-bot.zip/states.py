# -*- coding: utf-8 -*-
"""
Состояния для ConversationHandler
"""

from enum import Enum

class ShiftStates:
    """Состояния для управления сменами"""
    # Начало смены
    SPEEDOMETER_PHOTO = "speedometer_photo"
    FUEL_PHOTO = "fuel_photo"
    OIL_PHOTO = "oil_photo"
    INTERIOR_PHOTO = "interior_photo"
    
    # Завершение смены
    END_SPEEDOMETER = "end_speedometer"
    END_FUEL_PHOTO = "end_fuel_photo"

class AdminStates:
    """Состояния для административной панели"""
    # Добавление водителя
    ADD_DRIVER_PHONE = "add_driver_phone"
    ADD_DRIVER_NAME = "add_driver_name"
    
    # Добавление автомобиля
    ADD_CAR_MODEL = "add_car_model"
    ADD_CAR_NUMBER = "add_car_number"
