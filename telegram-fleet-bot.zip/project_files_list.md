# Список файлов проекта для загрузки на GitHub

## Основные файлы бота (Python)
1. **main.py** - главный файл запуска бота
2. **config.py** - настройки и конфигурация
3. **database.py** - подключение к базе данных
4. **models.py** - модели SQLAlchemy для БД
5. **handlers.py** - основные обработчики команд
6. **admin_handlers.py** - административные обработчики
7. **keyboards.py** - клавиатуры для интерфейса
8. **states.py** - состояния диалогов
9. **utils.py** - вспомогательные функции

## Документация и настройки
10. **README.md** - описание проекта
11. **replit.md** - техническая документация
12. **DEPLOYMENT_GUIDE.md** - инструкция по загрузке на GitHub
13. **project_files_list.md** - этот файл со списком

## Конфигурационные файлы
14. **.gitignore** - игнорируемые файлы для git
15. **requirements_github.txt** - зависимости Python (переименовать в requirements.txt)
16. **.env.example** - пример файла с переменными окружения

## Всего файлов: 16

---

## Быстрые команды для загрузки

### Создание архива (опционально)
```bash
tar -czf telegram-fleet-bot.tar.gz *.py *.md .gitignore requirements_github.txt .env.example
```

### Git команды для загрузки
```bash
git init
git remote add origin https://github.com/ВАШ_USERNAME/telegram-fleet-bot.git
git add .
git commit -m "Initial commit: Telegram Fleet Management Bot"
git branch -M main
git push -u origin main
```

---
*Все файлы готовы для загрузки на GitHub!*