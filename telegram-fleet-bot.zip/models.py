# -*- coding: utf-8 -*-
"""
Модели базы данных
"""

from sqlalchemy import Column, Integer, String, DateTime, Boolean, ForeignKey, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from database import Base

class Driver(Base):
    """Модель водителя"""
    __tablename__ = 'drivers'
    
    id = Column(Integer, primary_key=True, index=True)
    telegram_id = Column(Integer, unique=True, index=True)
    phone = Column(String(20), unique=True, index=True)
    name = Column(String(100), nullable=False)
    role = Column(String(20), default='driver')  # driver, admin
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Связи
    shifts = relationship("Shift", back_populates="driver")
    
    def __repr__(self):
        return f"<Driver(id={self.id}, name='{self.name}', phone='{self.phone}')>"

class Car(Base):
    """Модель автомобиля"""
    __tablename__ = 'cars'
    
    id = Column(Integer, primary_key=True, index=True)
    model = Column(String(100), nullable=False)
    license_plate = Column(String(20), unique=True, nullable=False)
    is_available = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Связи
    shifts = relationship("Shift", back_populates="car")
    
    def __repr__(self):
        return f"<Car(id={self.id}, model='{self.model}', plate='{self.license_plate}')>"

class Shift(Base):
    """Модель смены"""
    __tablename__ = 'shifts'
    
    id = Column(Integer, primary_key=True, index=True)
    driver_id = Column(Integer, ForeignKey('drivers.id'), nullable=False)
    car_id = Column(Integer, ForeignKey('cars.id'), nullable=False)
    
    start_time = Column(DateTime, default=datetime.utcnow)
    end_time = Column(DateTime, nullable=True)
    
    start_mileage = Column(Integer, nullable=True)
    end_mileage = Column(Integer, nullable=True)
    
    status = Column(String(20), default='active')  # active, completed, cancelled
    notes = Column(Text, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Связи
    driver = relationship("Driver", back_populates="shifts")
    car = relationship("Car", back_populates="shifts")
    photos = relationship("ShiftPhoto", back_populates="shift")
    
    @property
    def duration_hours(self):
        """Длительность смены в часах"""
        if self.end_time:
            duration = self.end_time - self.start_time
            return round(duration.total_seconds() / 3600, 2)
        return 0
    
    @property
    def mileage_driven(self):
        """Пробег за смену"""
        if self.start_mileage and self.end_mileage:
            return self.end_mileage - self.start_mileage
        return 0
    
    def __repr__(self):
        return f"<Shift(id={self.id}, driver_id={self.driver_id}, car_id={self.car_id}, status='{self.status}')>"

class ShiftPhoto(Base):
    """Модель фотографий смены"""
    __tablename__ = 'shift_photos'
    
    id = Column(Integer, primary_key=True, index=True)
    shift_id = Column(Integer, ForeignKey('shifts.id'), nullable=False)
    
    photo_type = Column(String(50), nullable=False)  # speedometer, fuel, oil, interior
    phase = Column(String(20), nullable=False)  # start, end
    file_id = Column(String(255), nullable=False)
    file_path = Column(String(500), nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Связи
    shift = relationship("Shift", back_populates="photos")
    
    def __repr__(self):
        return f"<ShiftPhoto(id={self.id}, shift_id={self.shift_id}, type='{self.photo_type}', phase='{self.phase}')>"
