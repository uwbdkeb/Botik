# -*- coding: utf-8 -*-
"""
Конфигурация бота
"""

import os
from dotenv import load_dotenv

# Загрузка переменных окружения
load_dotenv()

# Токен бота
BOT_TOKEN = os.getenv('BOT_TOKEN', '')
if not BOT_TOKEN:
    raise ValueError("BOT_TOKEN не найден в переменных окружения")

# База данных
DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///fleet_bot.db')

# Настройки приложения
DEBUG = os.getenv('DEBUG', 'False').lower() == 'true'

# ID администраторов (можно добавить через переменные окружения)
ADMIN_IDS = list(map(int, os.getenv('ADMIN_IDS', '').split(','))) if os.getenv('ADMIN_IDS') else []

# Настройки фото
MAX_PHOTO_SIZE = 20 * 1024 * 1024  # 20 MB
PHOTO_FORMATS = ['image/jpeg', 'image/png', 'image/webp']

# Сообщения
MESSAGES = {
    'welcome': """🚗 Добро пожаловать в систему управления автопарком!

Для начала работы поделитесь своим контактом, нажав кнопку ниже.""",
    
    'auth_success': """✅ Авторизация успешна!

Добро пожаловать, {name}!

Доступные команды:
🚗 /fleet - Автопарк
👤 /profile - Профиль
❓ /help - Помощь""",
    
    'auth_failed': """❌ Доступ запрещен.

Ваш номер телефона не найден в системе. Обратитесь к администратору.""",
    
    'help_text': """📖 Помощь по командам:

🚗 /fleet - Просмотр автопарка и управление сменами
👤 /profile - Информация о профиле
❓ /help - Эта справка

👨‍💼 Для администраторов:
/admin - Административная панель""",
    
    'profile_text': """👤 Ваш профиль:

📱 Телефон: {phone}
👤 Имя: {name}
🔐 Роль: {role}
📅 Дата регистрации: {created_at}

📊 Статистика:
🚗 Всего смен: {total_shifts}
⏱️ Общее время работы: {total_hours} ч.""",
    
    'fleet_empty': """🚗 Автопарк пуст.

Обратитесь к администратору для добавления автомобилей.""",
    
    'shift_start_photos': {
        'speedometer': '📊 Сфотографируйте спидометр',
        'fuel': '⛽ Сфотографируйте уровень топлива',
        'oil': '🛢️ Сфотографируйте уровень масла',
        'interior': '🚗 Сфотографируйте салон автомобиля'
    },
    
    'shift_end_photos': {
        'speedometer': '📊 Сфотографируйте итоговые показания спидометра',
        'fuel': '⛽ Сфотографируйте финальный уровень топлива'
    }
}
