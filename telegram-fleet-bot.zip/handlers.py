# -*- coding: utf-8 -*-
"""
Основные обработчики бота
"""

import logging
from datetime import datetime
from telegram import Update
from telegram.ext import ContextTypes, ConversationHandler
from telegram.constants import ParseMode

from database import get_db
from models import Driver, Car, Shift, ShiftPhoto
from keyboards import (
    get_contact_keyboard, get_main_menu_keyboard, get_fleet_keyboard,
    get_shift_control_keyboard
)
from states import ShiftStates
from config import MESSAGES
from utils import is_admin, get_user_from_db, create_shift_photo

logger = logging.getLogger(__name__)

async def start_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /start"""
    user = update.effective_user
    db = get_db()
    
    try:
        # Проверяем, есть ли пользователь в базе
        driver = db.query(Driver).filter(Driver.telegram_id == user.id).first()
        
        if driver and driver.is_active:
            await update.message.reply_text(
                MESSAGES['auth_success'].format(name=driver.name),
                reply_markup=get_main_menu_keyboard()
            )
        else:
            await update.message.reply_text(
                MESSAGES['welcome'],
                reply_markup=get_contact_keyboard()
            )
    except Exception as e:
        logger.error(f"Ошибка в start_handler: {e}")
        await update.message.reply_text("Произошла ошибка. Попробуйте позже.")
    finally:
        db.close()

async def contact_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик получения контакта"""
    contact = update.message.contact
    user = update.effective_user
    db = get_db()
    
    try:
        # Проверяем, что контакт принадлежит пользователю
        if contact.user_id != user.id:
            await update.message.reply_text("❌ Пожалуйста, поделитесь своим контактом.")
            return
        
        # Ищем водителя по номеру телефона
        phone = contact.phone_number
        if not phone.startswith('+'):
            phone = '+' + phone
            
        driver = db.query(Driver).filter(Driver.phone == phone).first()
        
        if driver and driver.is_active:
            # Обновляем telegram_id
            driver.telegram_id = user.id
            db.commit()
            
            await update.message.reply_text(
                MESSAGES['auth_success'].format(name=driver.name),
                reply_markup=get_main_menu_keyboard()
            )
        else:
            await update.message.reply_text(MESSAGES['auth_failed'])
            
    except Exception as e:
        logger.error(f"Ошибка в contact_handler: {e}")
        await update.message.reply_text("Произошла ошибка при авторизации.")
    finally:
        db.close()

async def profile_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /profile"""
    user = update.effective_user
    db = get_db()
    
    try:
        driver = get_user_from_db(user.id, db)
        if not driver:
            await update.message.reply_text("❌ Вы не авторизованы.")
            return
        
        # Получаем статистику
        total_shifts = db.query(Shift).filter(Shift.driver_id == driver.id).count()
        completed_shifts = db.query(Shift).filter(
            Shift.driver_id == driver.id,
            Shift.status == 'completed'
        ).all()
        
        total_hours = sum(shift.duration_hours for shift in completed_shifts)
        
        profile_text = MESSAGES['profile_text'].format(
            phone=driver.phone,
            name=driver.name,
            role="Администратор" if driver.role == 'admin' else "Водитель",
            created_at=driver.created_at.strftime("%d.%m.%Y"),
            total_shifts=total_shifts,
            total_hours=total_hours
        )
        
        await update.message.reply_text(profile_text, parse_mode=ParseMode.HTML)
        
    except Exception as e:
        logger.error(f"Ошибка в profile_handler: {e}")
        await update.message.reply_text("Произошла ошибка при получении профиля.")
    finally:
        db.close()

async def fleet_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /fleet"""
    user = update.effective_user
    db = get_db()
    
    try:
        driver = get_user_from_db(user.id, db)
        if not driver:
            await update.message.reply_text("❌ Вы не авторизованы.")
            return
        
        # Получаем список автомобилей
        cars = db.query(Car).all()
        
        if not cars:
            await update.message.reply_text(MESSAGES['fleet_empty'])
            return
        
        # Проверяем активную смену пользователя
        user_shift = db.query(Shift).filter(
            Shift.driver_id == driver.id,
            Shift.status == 'active'
        ).first()
        
        # Обновляем статус доступности автомобилей
        for car in cars:
            active_shift = db.query(Shift).filter(
                Shift.car_id == car.id,
                Shift.status == 'active'
            ).first()
            car.is_available = active_shift is None
        
        text = "🚗 **Автопарк**\n\nВыберите автомобиль для начала смены:"
        keyboard = get_fleet_keyboard(cars, user_shift)
        
        if update.message:
            await update.message.reply_text(text, reply_markup=keyboard, parse_mode=ParseMode.MARKDOWN)
        else:
            await update.callback_query.edit_message_text(text, reply_markup=keyboard, parse_mode=ParseMode.MARKDOWN)
        
    except Exception as e:
        logger.error(f"Ошибка в fleet_handler: {e}")
        error_text = "Произошла ошибка при получении списка автомобилей."
        if update.message:
            await update.message.reply_text(error_text)
        else:
            await update.callback_query.answer(error_text, show_alert=True)
    finally:
        db.close()

async def help_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /help"""
    await update.message.reply_text(MESSAGES['help_text'])

async def start_shift_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Начало смены - выбор автомобиля"""
    query = update.callback_query
    await query.answer()
    
    user = update.effective_user
    car_id = int(query.data.split('_')[2])
    db = get_db()
    
    try:
        driver = get_user_from_db(user.id, db)
        if not driver:
            await query.edit_message_text("❌ Вы не авторизованы.")
            return ConversationHandler.END
        
        # Проверяем, нет ли активной смены у водителя
        existing_shift = db.query(Shift).filter(
            Shift.driver_id == driver.id,
            Shift.status == 'active'
        ).first()
        
        if existing_shift:
            await query.edit_message_text("❌ У вас уже есть активная смена.")
            return ConversationHandler.END
        
        # Проверяем доступность автомобиля
        car = db.query(Car).filter(Car.id == car_id).first()
        if not car:
            await query.edit_message_text("❌ Автомобиль не найден.")
            return ConversationHandler.END
        
        car_shift = db.query(Shift).filter(
            Shift.car_id == car_id,
            Shift.status == 'active'
        ).first()
        
        if car_shift:
            await query.edit_message_text("❌ Автомобиль уже занят.")
            return ConversationHandler.END
        
        # Создаем новую смену
        shift = Shift(
            driver_id=driver.id,
            car_id=car_id,
            status='active'
        )
        db.add(shift)
        db.commit()
        
        # Сохраняем ID смены в контексте
        context.user_data['shift_id'] = shift.id
        context.user_data['car_model'] = car.model
        context.user_data['car_plate'] = car.license_plate
        
        # Запрашиваем первое фото - спидометр
        text = f"🚗 Смена началась: {car.model} ({car.license_plate})\n\n"
        text += MESSAGES['shift_start_photos']['speedometer']
        
        keyboard = get_shift_control_keyboard(shift.id)
        await query.edit_message_text(text, reply_markup=keyboard)
        
        return ShiftStates.SPEEDOMETER_PHOTO
        
    except Exception as e:
        logger.error(f"Ошибка в start_shift_handler: {e}")
        await query.edit_message_text("Произошла ошибка при начале смены.")
        return ConversationHandler.END
    finally:
        db.close()

async def shift_photo_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик фотографий смены"""
    user = update.effective_user
    photo = update.message.photo[-1]  # Берем фото лучшего качества
    shift_id = context.user_data.get('shift_id')
    
    if not shift_id:
        await update.message.reply_text("❌ Смена не найдена.")
        return ConversationHandler.END
    
    db = get_db()
    
    try:
        # Определяем тип и фазу фотографии по состоянию
        current_state = context.user_data.get('state', ShiftStates.SPEEDOMETER_PHOTO)
        
        state_mapping = {
            ShiftStates.SPEEDOMETER_PHOTO: ('speedometer', 'start'),
            ShiftStates.FUEL_PHOTO: ('fuel', 'start'),
            ShiftStates.OIL_PHOTO: ('oil', 'start'),
            ShiftStates.INTERIOR_PHOTO: ('interior', 'start'),
            ShiftStates.END_SPEEDOMETER: ('speedometer', 'end'),
            ShiftStates.END_FUEL_PHOTO: ('fuel', 'end')
        }
        
        photo_type, phase = state_mapping.get(current_state, ('unknown', 'start'))
        
        # Сохраняем фото в базу
        create_shift_photo(shift_id, photo_type, phase, photo.file_id, db)
        
        # Переходим к следующему шагу
        next_state = get_next_shift_state(current_state)
        
        if next_state:
            context.user_data['state'] = next_state
            next_message = get_next_photo_message(next_state)
            keyboard = get_shift_control_keyboard(shift_id)
            await update.message.reply_text(f"✅ Фото сохранено!\n\n{next_message}", reply_markup=keyboard)
            return next_state
        else:
            # Смена начата полностью
            shift = db.query(Shift).filter(Shift.id == shift_id).first()
            car_info = f"{context.user_data['car_model']} ({context.user_data['car_plate']})"
            
            await update.message.reply_text(
                f"✅ Смена успешно начата!\n\n🚗 Автомобиль: {car_info}\n⏰ Время начала: {shift.start_time.strftime('%d.%m.%Y %H:%M')}\n\nХорошей работы! 🚀"
            )
            
            # Очищаем данные пользователя
            context.user_data.clear()
            return ConversationHandler.END
            
    except Exception as e:
        logger.error(f"Ошибка в shift_photo_handler: {e}")
        await update.message.reply_text("Произошла ошибка при сохранении фото.")
        return ConversationHandler.END
    finally:
        db.close()

async def shift_text_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик текстовых сообщений во время смены"""
    await update.message.reply_text("📸 Пожалуйста, отправьте фотографию или воспользуйтесь кнопками ниже.")
    return None  # Остаемся в текущем состоянии

async def shift_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик callback для управления сменой"""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    
    if data.startswith('skip_photo_'):
        shift_id = int(data.split('_')[2])
        current_state = context.user_data.get('state', ShiftStates.SPEEDOMETER_PHOTO)
        
        # Переходим к следующему шагу без сохранения фото
        next_state = get_next_shift_state(current_state)
        
        if next_state:
            context.user_data['state'] = next_state
            next_message = get_next_photo_message(next_state)
            keyboard = get_shift_control_keyboard(shift_id)
            await query.edit_message_text(f"⏭️ Фото пропущено.\n\n{next_message}", reply_markup=keyboard)
            return next_state
        else:
            await query.edit_message_text("✅ Смена успешно начата!")
            context.user_data.clear()
            return ConversationHandler.END
    
    elif data.startswith('end_shift_'):
        return await end_shift_handler(update, context)
    
    elif data.startswith('cancel_shift_'):
        return await cancel_shift_handler(update, context)
    
    return None

async def end_shift_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Завершение смены"""
    query = update.callback_query
    user = update.effective_user
    shift_id = int(query.data.split('_')[2])
    db = get_db()
    
    try:
        driver = get_user_from_db(user.id, db)
        if not driver:
            await query.edit_message_text("❌ Вы не авторизованы.")
            return ConversationHandler.END
        
        shift = db.query(Shift).filter(
            Shift.id == shift_id,
            Shift.driver_id == driver.id,
            Shift.status == 'active'
        ).first()
        
        if not shift:
            await query.edit_message_text("❌ Активная смена не найдена.")
            return ConversationHandler.END
        
        # Сохраняем данные смены
        context.user_data['shift_id'] = shift_id
        context.user_data['state'] = ShiftStates.END_SPEEDOMETER
        
        # Запрашиваем финальное фото спидометра
        text = "🔚 Завершение смены\n\n"
        text += MESSAGES['shift_end_photos']['speedometer']
        
        keyboard = get_shift_control_keyboard(shift_id)
        await query.edit_message_text(text, reply_markup=keyboard)
        
        return ShiftStates.END_SPEEDOMETER
        
    except Exception as e:
        logger.error(f"Ошибка в end_shift_handler: {e}")
        await query.edit_message_text("Произошла ошибка при завершении смены.")
        return ConversationHandler.END
    finally:
        db.close()

async def cancel_shift_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Отмена смены"""
    user = update.effective_user
    db = get_db()
    
    try:
        shift_id = context.user_data.get('shift_id')
        if shift_id:
            shift = db.query(Shift).filter(Shift.id == shift_id).first()
            if shift:
                shift.status = 'cancelled'
                shift.end_time = datetime.utcnow()
                db.commit()
        
        # Очищаем данные
        context.user_data.clear()
        
        if update.callback_query:
            await update.callback_query.edit_message_text("❌ Смена отменена.")
        else:
            await update.message.reply_text("❌ Смена отменена.")
        
        return ConversationHandler.END
        
    except Exception as e:
        logger.error(f"Ошибка в cancel_shift_handler: {e}")
        error_text = "Произошла ошибка при отмене смены."
        if update.callback_query:
            await update.callback_query.edit_message_text(error_text)
        else:
            await update.message.reply_text(error_text)
        return ConversationHandler.END
    finally:
        db.close()

def get_next_shift_state(current_state):
    """Получить следующее состояние смены"""
    state_flow = {
        ShiftStates.SPEEDOMETER_PHOTO: ShiftStates.FUEL_PHOTO,
        ShiftStates.FUEL_PHOTO: ShiftStates.OIL_PHOTO,
        ShiftStates.OIL_PHOTO: ShiftStates.INTERIOR_PHOTO,
        ShiftStates.INTERIOR_PHOTO: None,  # Конец начала смены
        ShiftStates.END_SPEEDOMETER: ShiftStates.END_FUEL_PHOTO,
        ShiftStates.END_FUEL_PHOTO: None  # Конец завершения смены
    }
    
    return state_flow.get(current_state)

def get_next_photo_message(state):
    """Получить сообщение для следующего фото"""
    if state == ShiftStates.FUEL_PHOTO:
        return MESSAGES['shift_start_photos']['fuel']
    elif state == ShiftStates.OIL_PHOTO:
        return MESSAGES['shift_start_photos']['oil']
    elif state == ShiftStates.INTERIOR_PHOTO:
        return MESSAGES['shift_start_photos']['interior']
    elif state == ShiftStates.END_FUEL_PHOTO:
        return MESSAGES['shift_end_photos']['fuel']
    
    return "📸 Отправьте фотографию"
