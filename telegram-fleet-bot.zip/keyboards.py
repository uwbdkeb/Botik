# -*- coding: utf-8 -*-
"""
Клавиатуры для бота
"""

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, KeyboardButton, ReplyKeyboardMarkup

def get_contact_keyboard():
    """Клавиатура для запроса контакта"""
    keyboard = [[KeyboardButton("📱 Поделиться контактом", request_contact=True)]]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True)

def get_main_menu_keyboard():
    """Главное меню"""
    keyboard = [
        [InlineKeyboardButton("🚗 Автопарк", callback_data="fleet")],
        [InlineKeyboardButton("👤 Профиль", callback_data="profile")],
        [InlineKeyboardButton("📊 Отчеты", callback_data="reports")],
        [InlineKeyboardButton("❓ Помощь", callback_data="help")]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_fleet_keyboard(cars, user_shift=None):
    """Клавиатура автопарка"""
    keyboard = []
    
    for car in cars:
        if car.is_available:
            status = "🟢"
            callback_data = f"start_shift_{car.id}"
        else:
            status = "🔴"
            callback_data = f"car_info_{car.id}"
            
        text = f"{status} {car.model} ({car.license_plate})"
        keyboard.append([InlineKeyboardButton(text, callback_data=callback_data)])
    
    # Кнопка завершения смены, если есть активная смена
    if user_shift:
        keyboard.append([InlineKeyboardButton("🔴 Завершить смену", callback_data=f"end_shift_{user_shift.id}")])
    
    keyboard.append([InlineKeyboardButton("🔄 Обновить", callback_data="fleet")])
    keyboard.append([InlineKeyboardButton("◀️ Назад", callback_data="back_to_main")])
    
    return InlineKeyboardMarkup(keyboard)

def get_shift_control_keyboard(shift_id):
    """Клавиатура управления сменой"""
    keyboard = [
        [InlineKeyboardButton("📸 Пропустить фото", callback_data=f"skip_photo_{shift_id}")],
        [InlineKeyboardButton("🔄 Переснять", callback_data=f"retake_photo_{shift_id}")],
        [InlineKeyboardButton("❌ Отменить смену", callback_data=f"cancel_shift_{shift_id}")]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_admin_keyboard():
    """Административная панель"""
    keyboard = [
        [InlineKeyboardButton("👥 Управление водителями", callback_data="admin_drivers")],
        [InlineKeyboardButton("🚗 Управление автомобилями", callback_data="admin_cars")],
        [InlineKeyboardButton("📊 Отчеты", callback_data="admin_reports")],
        [InlineKeyboardButton("⚙️ Настройки", callback_data="admin_settings")]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_admin_drivers_keyboard():
    """Управление водителями"""
    keyboard = [
        [InlineKeyboardButton("➕ Добавить водителя", callback_data="admin_add_driver")],
        [InlineKeyboardButton("📋 Список водителей", callback_data="admin_list_drivers")],
        [InlineKeyboardButton("◀️ Назад", callback_data="admin")]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_admin_cars_keyboard():
    """Управление автомобилями"""
    keyboard = [
        [InlineKeyboardButton("➕ Добавить автомобиль", callback_data="admin_add_car")],
        [InlineKeyboardButton("📋 Список автомобилей", callback_data="admin_list_cars")],
        [InlineKeyboardButton("◀️ Назад", callback_data="admin")]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_driver_list_keyboard(drivers, page=0, per_page=5):
    """Клавиатура со списком водителей"""
    keyboard = []
    
    start_idx = page * per_page
    end_idx = start_idx + per_page
    
    for driver in drivers[start_idx:end_idx]:
        status = "✅" if driver.is_active else "❌"
        role = "👨‍💼" if driver.role == 'admin' else "🚗"
        text = f"{status} {role} {driver.name}"
        keyboard.append([InlineKeyboardButton(text, callback_data=f"admin_driver_{driver.id}")])
    
    # Пагинация
    nav_buttons = []
    if page > 0:
        nav_buttons.append(InlineKeyboardButton("◀️", callback_data=f"admin_drivers_page_{page-1}"))
    if end_idx < len(drivers):
        nav_buttons.append(InlineKeyboardButton("▶️", callback_data=f"admin_drivers_page_{page+1}"))
    
    if nav_buttons:
        keyboard.append(nav_buttons)
    
    keyboard.append([InlineKeyboardButton("◀️ Назад", callback_data="admin_drivers")])
    
    return InlineKeyboardMarkup(keyboard)

def get_car_list_keyboard(cars, page=0, per_page=5):
    """Клавиатура со списком автомобилей"""
    keyboard = []
    
    start_idx = page * per_page
    end_idx = start_idx + per_page
    
    for car in cars[start_idx:end_idx]:
        status = "🟢" if car.is_available else "🔴"
        text = f"{status} {car.model} ({car.license_plate})"
        keyboard.append([InlineKeyboardButton(text, callback_data=f"admin_car_{car.id}")])
    
    # Пагинация
    nav_buttons = []
    if page > 0:
        nav_buttons.append(InlineKeyboardButton("◀️", callback_data=f"admin_cars_page_{page-1}"))
    if end_idx < len(cars):
        nav_buttons.append(InlineKeyboardButton("▶️", callback_data=f"admin_cars_page_{page+1}"))
    
    if nav_buttons:
        keyboard.append(nav_buttons)
    
    keyboard.append([InlineKeyboardButton("◀️ Назад", callback_data="admin_cars")])
    
    return InlineKeyboardMarkup(keyboard)

def get_confirmation_keyboard(action, item_id):
    """Клавиатура подтверждения действия"""
    keyboard = [
        [InlineKeyboardButton("✅ Да", callback_data=f"confirm_{action}_{item_id}")],
        [InlineKeyboardButton("❌ Нет", callback_data=f"cancel_{action}_{item_id}")]
    ]
    return InlineKeyboardMarkup(keyboard)
