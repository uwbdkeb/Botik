# -*- coding: utf-8 -*-
"""
Настройка базы данных
"""

from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from config import DATABASE_URL

# Создание движка базы данных
engine = create_engine(DATABASE_URL, echo=False)

# Создание сессии
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Базовый класс для моделей
Base = declarative_base()

def get_db():
    """Получение сессии базы данных"""
    db = SessionLocal()
    try:
        return db
    finally:
        pass

def init_db():
    """Инициализация базы данных"""
    from models import Driver, Car, Shift, ShiftPhoto
    try:
        Base.metadata.create_all(bind=engine, checkfirst=True)
    except Exception as e:
        print(f"Таблицы уже существуют или ошибка создания: {e}")
    
    # Создание администратора по умолчанию (если не существует)
    db = get_db()
    try:
        admin = db.query(Driver).filter(Driver.role == 'admin').first()
        if not admin:
            # Можно добавить создание администратора по умолчанию
            pass
    except Exception as e:
        print(f"Ошибка при инициализации: {e}")
    finally:
        db.close()
