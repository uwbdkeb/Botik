# -*- coding: utf-8 -*-
"""
Утилиты и вспомогательные функции
"""

import logging
from datetime import datetime
from typing import Optional

from database import get_db
from models import Driver, ShiftPhoto
from config import ADMIN_IDS

logger = logging.getLogger(__name__)

def is_admin(user_id: int, db) -> bool:
    """Проверка прав администратора"""
    try:
        # Проверяем в настройках
        if user_id in ADMIN_IDS:
            return True
        
        # Проверяем в базе данных
        driver = db.query(Driver).filter(
            Driver.telegram_id == user_id,
            Driver.role == 'admin',
            Driver.is_active == True
        ).first()
        
        return driver is not None
    except Exception as e:
        logger.error(f"Ошибка проверки прав администратора: {e}")
        return False

def get_user_from_db(user_id: int, db) -> Optional[Driver]:
    """Получить пользователя из базы данных"""
    try:
        return db.query(Driver).filter(
            Driver.telegram_id == user_id,
            Driver.is_active == True
        ).first()
    except Exception as e:
        logger.error(f"Ошибка получения пользователя: {e}")
        return None

def create_shift_photo(shift_id: int, photo_type: str, phase: str, file_id: str, db):
    """Создать запись о фотографии смены"""
    try:
        photo = ShiftPhoto(
            shift_id=shift_id,
            photo_type=photo_type,
            phase=phase,
            file_id=file_id,
            created_at=datetime.utcnow()
        )
        
        db.add(photo)
        db.commit()
        
        logger.info(f"Фото сохранено: shift_id={shift_id}, type={photo_type}, phase={phase}")
        return photo
    except Exception as e:
        logger.error(f"Ошибка сохранения фото: {e}")
        db.rollback()
        raise

def format_duration(seconds: int) -> str:
    """Форматирование длительности в читаемый вид"""
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    
    if hours > 0:
        return f"{hours} ч {minutes} мин"
    else:
        return f"{minutes} мин"

def validate_phone_number(phone: str) -> bool:
    """Валидация номера телефона"""
    if not phone:
        return False
    
    # Убираем все символы кроме цифр и +
    clean_phone = ''.join(c for c in phone if c.isdigit() or c == '+')
    
    # Проверяем формат
    if not clean_phone.startswith('+'):
        return False
    
    # Проверяем длину (от 11 до 15 символов включая +)
    if len(clean_phone) < 11 or len(clean_phone) > 15:
        return False
    
    return True

def validate_license_plate(plate: str) -> bool:
    """Валидация государственного номера"""
    if not plate:
        return False
    
    # Убираем пробелы и приводим к верхнему регистру
    clean_plate = plate.strip().upper()
    
    # Проверяем минимальную длину
    if len(clean_plate) < 5:
        return False
    
    return True

def get_shift_status_text(status: str) -> str:
    """Получить текстовое описание статуса смены"""
    status_map = {
        'active': '🟢 Активна',
        'completed': '✅ Завершена',
        'cancelled': '❌ Отменена'
    }
    
    return status_map.get(status, '❓ Неизвестно')

def get_role_text(role: str) -> str:
    """Получить текстовое описание роли"""
    role_map = {
        'admin': '👨‍💼 Администратор',
        'driver': '🚗 Водитель'
    }
    
    return role_map.get(role, '❓ Неизвестно')

def format_date(dt: datetime) -> str:
    """Форматирование даты для отображения"""
    if not dt:
        return "Не указано"
    
    return dt.strftime("%d.%m.%Y %H:%M")

def format_date_short(dt: datetime) -> str:
    """Короткое форматирование даты"""
    if not dt:
        return "Не указано"
    
    return dt.strftime("%d.%m.%Y")

def calculate_mileage(start_mileage: Optional[int], end_mileage: Optional[int]) -> int:
    """Вычислить пробег"""
    if start_mileage is None or end_mileage is None:
        return 0
    
    if end_mileage < start_mileage:
        return 0
    
    return end_mileage - start_mileage

def log_user_action(user_id: int, action: str, details: str = ""):
    """Логирование действий пользователя"""
    try:
        logger.info(f"User {user_id}: {action} - {details}")
    except Exception as e:
        logger.error(f"Ошибка логирования: {e}")

def safe_int_convert(value: str) -> Optional[int]:
    """Безопасное преобразование строки в число"""
    try:
        return int(value.strip())
    except (ValueError, AttributeError):
        return None

def clean_text(text: str) -> str:
    """Очистка текста от лишних символов"""
    if not text:
        return ""
    
    return text.strip()

def truncate_text(text: str, max_length: int = 100) -> str:
    """Обрезка текста до указанной длины"""
    if not text:
        return ""
    
    if len(text) <= max_length:
        return text
    
    return text[:max_length-3] + "..."

def get_file_extension(filename: str) -> str:
    """Получить расширение файла"""
    if not filename or '.' not in filename:
        return ""
    
    return filename.split('.')[-1].lower()

def is_valid_photo_format(mime_type: str) -> bool:
    """Проверка валидного формата фотографии"""
    from config import PHOTO_FORMATS
    return mime_type in PHOTO_FORMATS

def generate_report_filename(report_type: str) -> str:
    """Генерация имени файла для отчета"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"fleet_report_{report_type}_{timestamp}.xlsx"
